$(document).ready(function(){

  var array = [];
  var elems = [];
  var body = [];
  var currentUrl = document.URL;

  function sendMessage () {
    var tabBody = document.body.innerHTML;
    var tabUrl = currentUrl;

    chrome.runtime.sendMessage({req: "sendInfo", body: tabBody, url: tabUrl}, function(response) {
       console.log(response.res);
    });
  }

  function getBodyElements () {
    var len = $("body").find("*").length;

    for (var i = 0; i < len; i++) {

      var tag = $("body").find("*")[i];
      var tagName = tag.tagName.toLowerCase();
      var text = tag.innerHTML;

      if (/h[0-9]/.test(tagName) || tagName == "iframe" || tagName == "video") {
        array[i] = {
          content: text,
          tagname: tagName
        };

        if (text.length > 280) {
          array[i].tagname = "p";
        }
      }

      if (tagName == "p" && text.length > 140) {
        array[i] = {
          content: text,
          tagname: tagName
        };
      }
    }

    for (var j = 0; j < len; j++) {

      if (typeof array[j] != 'undefined') {
        elems.push(array[j]);
      }
    }

    elems = removeDuplicates(elems);
  }

  function removeDuplicates (arr) {
      var seen = {};
      var out = [];
      var len = arr.length;
      var j = 0;

      for (var i = 0; i < len; i++) {
         var item = arr[i];
         var content = item.content;
         if (seen[content] !== 1) {
           seen[content] = 1;
           out[j++] = item;
         }
      }
      return out;
  }


  function removeBodyElements () {
    $("body").find("*").remove();
  }

  function createZenMode () {
    $("body").append("<div class='zen-wrapper'></div>");

    for (var j = 0; j < elems.length; j++) {
      $(".zen-wrapper").append("<" + elems[j].tagname + ">" + elems[j].content + "</" + elems[j].tagname + ">");
    }
  }

  function removeZenMode (content) {
    removeBodyElements();
    $("body").append(content);
  }

  function getMessage () {
    var body = document.body.innerHTML;

    chrome.runtime.sendMessage({req: "getInfo", url: currentUrl}, function(response) {
      console.log(response.res);
      
      if (response.url == currentUrl) {
        removeZenMode(response.body);
      }
      else {
        zenMode = false;
      }
    });
  }

  function zenReading () {

    if (zenMode === false) {
      sendMessage();
      getBodyElements();
      removeBodyElements();
      createZenMode();
    }
    else {
      getMessage();
    }
  }

  zenReading();

});
