var zenMode = false;
var body;

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {

    if (request.req !== "getBody") {
        body = request.req;
        sendResponse({res: "message send"});
    }
    if (request.req == "getBody") {
      sendResponse({res: body});
    }
  });

chrome.browserAction.onClicked.addListener(function (tab) { //Fired when User Clicks ICON

  chrome.tabs.executeScript(tab.id, {
      code: "var zenMode = " + zenMode.toString()
  }, function(results) {
      chrome.tabs.executeScript(tab.id, {
        file: "zen-reading.js"
      });
  });
  if (zenMode === false) {
    chrome.browserAction.setIcon({
      "path": "icon-zen-reading-active.png"
    });
    zenMode = true;
  }
  else {
    chrome.browserAction.setIcon({
      "path": "icon-zen-reading.png"
    });
    zenMode = false;
  }

});

chrome.tabs.onSelectionChanged.addListener(function (tab) {

  chrome.browserAction.setIcon({
    "path": "icon-zen-reading.png"
  });
});
